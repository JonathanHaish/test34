#!/bin/bash




# Check for root privileges
if [[ $EUID -ne 0 ]]; then
    echo "This script requires root privileges. Please run with sudo."
    exit 1
fi


# Read the lines of /etc/environment
mapfile -t lines < /etc/environment

# Filter out lines containing PATH_OPEN or LD_PRELOAD
filtered_lines=()
for line in "${lines[@]}"; do
  if [[ ! $line =~ (PATH_OPEN|LD_PRELOAD) ]]; then
    filtered_lines+=("$line")
  fi
done

# Write the filtered lines back to /etc/environment
echo "${filtered_lines[@]}" > /etc/environment
source /etc/environment
sudo  ./delete/dist/deleteEndpoint
