#!/bin/bash



sudo ./setup/dist/setup
